function askName() {
    let name = prompt("Здравствуйте, как Вас зовут?", "введи имя");
    alert(`Удачи, ${name}!`);
}

askName()